import 'package:flutter/material.dart';
import '../../data/services/customer_ops_service.dart';
import '../../data/services/booking_service.dart';
import '../../widgets/forms/booking_form.dart';

class CreateBookingPage extends StatefulWidget {
  final String token;
  const CreateBookingPage({super.key, required this.token});

  @override
  State<CreateBookingPage> createState() => _CreateBookingPageState();
}

class _CreateBookingPageState extends State<CreateBookingPage> {
  List properties = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchProperties();
  }

  void fetchProperties() async {
    try {
      print("reached!");
      print("reached!");
     
      final res = await CustomerOpsService. getPropertiesByCategory('rental', widget.token);
      setState(() {
        properties = res['properties'] ?? [];
      });
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error fetching properties: $e')));
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  void handleBooking(Map<String, dynamic> data) async {
    try {
      final res = await BookingService.createBooking(
        token: widget.token,
        propertyId: data['propertyId'],
        startDate: data['startDate'],
        endDate: data['endDate'],
        timeInterval: data['timeInterval'],
        numberOfProperty: data['numberOfProperty'],
        securityDeposit: data['securityDeposit'],
        lang: 'en',
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message'] ?? 'Booking completed')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Booking failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Booking')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: BookingForm(
                properties: properties.cast<Map<String, dynamic>>(),
                onSubmit: handleBooking,
              ),
            ),
    );
  }
}
