import 'package:flutter/material.dart';
import '../../data/services/booking_service.dart';

class MyBookingsPage extends StatefulWidget {
  const MyBookingsPage({super.key});

  @override
  State<MyBookingsPage> createState() => _MyBookingsPageState();
}

class _MyBookingsPageState extends State<MyBookingsPage> {
  List bookings = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadBookings();
  }

  void _loadBookings() async {
    final token = 'USER_JWT_TOKEN';
    final res = await BookingService.getMyBookings(token);
    setState(() {
      bookings = res['bookings'] ?? [];
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Bookings')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: bookings.length,
              itemBuilder: (context, i) {
                final booking = bookings[i];
                return ListTile(
                  title: Text(booking['assetName']),
                  subtitle: Text('Status: ${booking['status']} | Total: ${booking['totalPrice']}'),
                );
              },
            ),
    );
  }
}
