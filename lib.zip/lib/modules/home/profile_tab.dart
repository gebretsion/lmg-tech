import 'package:flutter/material.dart';
import '../../data/services/auth_service.dart';

class ProfileTab extends StatefulWidget {
  final String token;
  const ProfileTab({super.key, required this.token});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  Map profile = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  void fetchProfile() async {
    try {
      final res = await AuthService.getProfile(widget.token);
      setState(() { profile = res; });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Failed to fetch profile')));
    } finally {
      setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return loading ? const Center(child: CircularProgressIndicator()) : Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          CircleAvatar(
            radius: 50,
            backgroundImage: NetworkImage(profile['profilePictureUrl'] ?? ''),
          ),
          const SizedBox(height: 16),
          Text(profile['fullName'] ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text(profile['email'] ?? ''),
          Text(profile['phonenumber']?.toString() ?? ''),
          Text(profile['address'] ?? ''),
        ],
      ),
    );
  }
}
