import 'package:flutter/material.dart';
import 'package:lmg_app/data/services/auth_service.dart';
import 'package:lmg_app/modules/auth/login_page.dart';
import 'package:lmg_app/modules/auth/register_page.dart';
import '../../data/models/property.dart';
import '../booking/property_booking_page.dart';
class PropertyDetailPage extends StatelessWidget {
  final Property property;

  const PropertyDetailPage({super.key, required this.property});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(property.name),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
          child: const Text('Book Now'),
          onPressed: () async {
            final token = await AuthService.getToken();
            if (token == null) {
              // User is not logged in, show login/register dialog
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text('Authentication Required'), // Title remains clear
                    content: const Text('You must sign in or sign up to create a booking.'), // Updated message
                    actions: <Widget>[
                      TextButton(
                        child: const Text('Register'),
                        onPressed: () {
                          Navigator.of(context).pop(); // Close the dialog
                          Navigator.push(context, MaterialPageRoute(builder: (_) => RegisterPage(property: property)));
                        },
                      ),
                      TextButton(
                        child: const Text('Login'),
                        onPressed: () {
                          Navigator.of(context).pop(); // Close the dialog
                          Navigator.push(context, MaterialPageRoute(builder: (_) => LoginPage(property: property)));
                        },
                      ),
                    ],
                  );
                },
              );
            } else {
              // User is logged in, proceed to booking
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => PropertyBookingPage(property: property)),
              );
            }
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (property.imageUrls.isNotEmpty)
              SizedBox(
                height: 200,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: property.imageUrls.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: Image.network(
                        property.imageUrls[index],
                        width: 250,
                        fit: BoxFit.cover,
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 16),
            Text(
              property.name,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              property.description,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            _buildDetailRow('Category:', property.category),
            _buildDetailRow('Status:', property.status),
            _buildDetailRow('Price Unit:', property.priceUnit.toString()),
            _buildDetailRow('Number of Units:', property.numberOfProperty.toString()),
            const SizedBox(height: 16),
            const Text(
              'Rental Prices:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            _buildDetailRow('Per Hour:', '${property.rentalPrice['perHour'] ?? 'N/A'}'),
            _buildDetailRow('Per Day:', '${property.rentalPrice['perDay'] ?? 'N/A'}'),
            _buildDetailRow('Per Month:', '${property.rentalPrice['perMonth'] ?? 'N/A'}'),
            _buildDetailRow('Per Year:', '${property.rentalPrice['perYear'] ?? 'N/A'}'),
            const SizedBox(height: 16),
            const Text(
              'Merchant Details:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            _buildDetailRow('Name:', property.merchant['name'] ?? 'N/A'),
            _buildDetailRow('Business Name:', property.merchant['businessName'] ?? 'N/A'),
            _buildDetailRow('Email:', property.merchant['email'] ?? 'N/A'),
            _buildDetailRow('Phone:', (property.merchant['phone'] ?? 'N/A').toString()),
            _buildDetailRow('Account Number:', (property.merchant['acountnumber'] ?? 'N/A').toString()),
            const SizedBox(height: 16),
            const Text(
              'Associated Bookings:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            if (property.bookings.isEmpty)
              const Text('No current bookings for this property.')
            else
              // Use a non-scrolling ListView.builder for efficiency
              ListView.builder(
                shrinkWrap: true, // Important for nesting in a SingleChildScrollView
                physics: const NeverScrollableScrollPhysics(), // Disable its own scrolling
                itemCount: property.bookings.length,
                itemBuilder: (context, index) {
                  final booking = property.bookings[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    child: ListTile(
                      title: Text('Booking from ${booking.startDate.split('T')[0]} to ${booking.endDate.split('T')[0]}'),
                      subtitle: Text('Status: ${booking.status} | Units: ${booking.numberOfProperty}'),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
