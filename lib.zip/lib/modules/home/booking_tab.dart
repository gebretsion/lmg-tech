import 'package:flutter/material.dart';
import '../../data/services/customer_ops_service.dart';
import 'package:lmg_app/modules/booking/create_booking_page.dart';

class BookingTab extends StatefulWidget {
  final String token;
  const BookingTab({super.key, required this.token});

  @override
  State<BookingTab> createState() => _BookingTabState();
}

class _BookingTabState extends State<BookingTab> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Booking'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Create'),
            Tab(text: 'My Bookings'),
            Tab(text: 'All Bookings'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          CreateBookingPage(token: widget.token),
          MyBookingsPage(token: widget.token),
          AllBookingsPage(token: widget.token),
        ],
      ),
    );
  }
}

// MyBookingsPage and AllBookingsPage can be similar: fetch and list bookings using CustomerOpsService
class MyBookingsPage extends StatefulWidget {
  final String token;
  const MyBookingsPage({super.key, required this.token});
  @override
  State<MyBookingsPage> createState() => _MyBookingsPageState();
}

class _MyBookingsPageState extends State<MyBookingsPage> {
  List bookings = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchBookings();
  }

  void fetchBookings() async {
    try {
      final res = await CustomerOpsService.getMyBookings(widget.token);
      setState(() { bookings = res['bookings'] ?? []; });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
      itemCount: bookings.length,
      itemBuilder: (context, index) {
        final booking = bookings[index];
        return Card(
          child: ListTile(
            title: Text(booking['assetName']),
            subtitle: Text('From ${booking['startDate']} To ${booking['endDate']}'),
          ),
        );
      },
    );
  }
}

class AllBookingsPage extends StatefulWidget {
  final String token;
  const AllBookingsPage({super.key, required this.token});
  @override
  State<AllBookingsPage> createState() => _AllBookingsPageState();
}

class _AllBookingsPageState extends State<AllBookingsPage> {
  List bookings = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchAllBookings();
  }

  void fetchAllBookings() async {
    try {
      final res = await CustomerOpsService.getAllBookings(widget.token);
      setState(() { bookings = res['bookings'] ?? []; });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return loading ? const Center(child: CircularProgressIndicator()) : ListView.builder(
      itemCount: bookings.length,
      itemBuilder: (context, index) {
        final booking = bookings[index];
        return Card(
          child: ListTile(
            title: Text(booking['propertyName'] ?? booking['assetName']),
            subtitle: Text('From ${booking['startDate']} To ${booking['endDate']}'),
          ),
        );
      },
    );
  }
}
