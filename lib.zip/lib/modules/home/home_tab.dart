import 'package:flutter/material.dart';
import '../../data/services/customer_ops_service.dart';

class HomeTab extends StatefulWidget {
  final String token;
  const HomeTab({super.key, required this.token});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final _categoryController = TextEditingController();
  bool loading = false;
  List properties = [];

  void searchProperties() async {
    if (_categoryController.text.isEmpty) return;
    setState(() { loading = true; });
    try {
      final res = await CustomerOpsService.getPropertiesByCategory(widget.token, _categoryController.text);
      setState(() { properties = res['properties'] ?? []; });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search Properties')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _categoryController,
              decoration: const InputDecoration(labelText: 'Category', suffixIcon: Icon(Icons.search)),
              onSubmitted: (_) => searchProperties(),
            ),
            const SizedBox(height: 16),
            loading ? const CircularProgressIndicator() : Expanded(
              child: ListView.builder(
                itemCount: properties.length,
                itemBuilder: (context, index) {
                  final property = properties[index];
                  return Card(
                    child: ListTile(
                      title: Text(property['name']),
                      subtitle: Text('${property['category']} - ${property['rentalPrice']['perDay']} per day'),
                      trailing: ElevatedButton(
                        child: const Text('Book'),
                        onPressed: () {
                          Navigator.pushNamed(context, '/booking/create', arguments: property);
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
