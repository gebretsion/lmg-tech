class Property {
  final String name;
  final String description;
  final String category;
  final Map<String, dynamic> rentalPrice;
  final int numberOfProperty;
  final String status;
  final List<String> imageUrls;
  final Map<String, dynamic> merchant;

  Property({
    required this.name,
    required this.description,
    required this.category,
    required this.rentalPrice,
    required this.numberOfProperty,
    required this.status,
    required this.imageUrls,
    required this.merchant,
  });

  factory Property.fromJson(Map<String, dynamic> json) => Property(
        name: json['name'],
        description: json['description'],
        category: json['category'],
        rentalPrice: json['rentalPrice'],
        numberOfProperty: json['numberOfProperty'],
        status: json['status'],
        imageUrls: List<String>.from(json['imageUrls'] ?? []),
        merchant: json['merchant'] ?? {},
      );
}
