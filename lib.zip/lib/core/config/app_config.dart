class AppConfig {
  // Base URL you provided:
  static const String baseUrl = 'http://10.14.26.245:3000';
}
