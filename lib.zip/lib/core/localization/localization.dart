import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  late Map<String, String> _localizedStrings;

  Future<bool> load() async {
    String languageCode = locale.languageCode;
    
    print('🔍 Loading translations for: $languageCode');
    
    try {
      String jsonString = await rootBundle.loadString('assets/lang/$languageCode.json');
      Map<String, dynamic> jsonMap = json.decode(jsonString);
      _localizedStrings = jsonMap.map((key, value) => MapEntry(key, value.toString()));
      
      print('✅ Successfully loaded $languageCode with ${_localizedStrings.length} translations');
      return true;
    } catch (e) {
      print('❌ Failed to load $languageCode.json: $e');
      
      // Fallback to English if not already English
      if (languageCode != 'en') {
        print('🔄 Falling back to English translations...');
        return await _loadFallbackTranslations();
      }
      
      print('⚠️ Even English failed, using empty translations');
      _localizedStrings = {};
      return false;
    }
  }

  Future<bool> _loadFallbackTranslations() async {
    try {
      String fallbackJsonString = await rootBundle.loadString('assets/lang/en.json');
      Map<String, dynamic> fallbackJsonMap = json.decode(fallbackJsonString);
      _localizedStrings = fallbackJsonMap.map((key, value) => MapEntry(key, value.toString()));
      print('✅ Fallback to English successful');
      return false; // Return false to indicate fallback was used
    } catch (e) {
      print('❌ Fallback to English also failed: $e');
      _localizedStrings = {};
      return false;
    }
  }

  String translate(String key) {
    return _localizedStrings[key] ?? key;
  }

  // Helper method to check if a key exists
  bool hasKey(String key) {
    return _localizedStrings.containsKey(key);
  }
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    return ['en', 'am', 'om'].contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async {
    final localizations = AppLocalizations(locale);
    await localizations.load();
    return localizations;
  }

  @override
  bool shouldReload(covariant LocalizationsDelegate<AppLocalizations> old) => true;
}